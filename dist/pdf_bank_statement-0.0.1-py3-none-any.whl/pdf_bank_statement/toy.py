from .__import import *

commoner = 1

def add_commoner():
    commoner += 1
    return commoner